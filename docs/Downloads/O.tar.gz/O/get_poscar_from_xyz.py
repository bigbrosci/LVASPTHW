#!/usr/bin/env python3
import numpy as np
from ase.io import read, write

def xyz_to_poscar(xyz_path, poscar_path, padding=10.0):
    # 1) Read the XYZ file
    atoms = read(xyz_path)

    # 2) (Optionally) ensure it’s a Fe cluster, 
#    atoms.symbols = ['Fe'] * len(atoms)

    # 3) Get min/max coordinates
    coords = atoms.get_positions()
    min_xyz = coords.min(axis=0)
    max_xyz = coords.max(axis=0)

    # 4) Compute box lengths = (max - min) + padding
    lengths = max_xyz - min_xyz + padding
    cell = np.diag(lengths)

    # 5) Center the cluster in the box
    box_center = min_xyz + lengths / 2.0
    cluster_com = atoms.get_center_of_mass()
    translation = box_center - cluster_com
    atoms.translate(translation)

    # 6) Assign cell and periodicity, then write POSCAR
    atoms.set_cell(cell)
    atoms.set_pbc([True, True, True])

    # 7) Center the atoms in the unit cell
    atoms.center()

    # 8) Wrap the atoms using the pbc (periodic boundary conditions) and cell
    atoms.wrap(pbc=True)

    # 9) Save the POSCAR file.
    write(poscar_path, atoms, format='vasp')

if __name__ == "__main__":
    import sys
    if len(sys.argv) != 3:
        print("Usage: python xyz_to_poscar.py input.xyz POSCAR")
        sys.exit(1)
    xyz_to_poscar(sys.argv[1], sys.argv[2])
